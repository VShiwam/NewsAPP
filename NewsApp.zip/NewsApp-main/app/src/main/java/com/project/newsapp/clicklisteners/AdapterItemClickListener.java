package com.project.newsapp.clicklisteners;

import com.project.newsapp.model.News;

public interface AdapterItemClickListener {

    void onNewsItemClick(News news);

}
